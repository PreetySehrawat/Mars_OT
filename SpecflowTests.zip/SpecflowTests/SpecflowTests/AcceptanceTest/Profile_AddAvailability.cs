﻿using OpenQA.Selenium;
using RelevantCodes.ExtentReports;
using SpecflowPages;
using System;
using System.Threading;
using TechTalk.SpecFlow;
using static SpecflowPages.CommonMethods;

namespace SpecflowTests
{
    [Binding]
    public class Profile_AddAvailability
    {
        [Given(@"I click on the edit availability under Profile page")]
        public void GivenIClickOnTheEditAvailabilityUnderProfilePage()
        {
            // Click on Edit Availabilty
            Driver.driver.FindElement(By.CssSelector("#account-profile-section > div > section:nth-child(3) > div > div > div > div.four.wide.column > div > div > div > div > div > div.extra.content > div > div:nth-child(2) > div > span > i")).Click();
        }
        
        [When(@"I choose my availability")]
        public void WhenIChooseMyAvailability()
        {   
            //Choose availability
            Driver.driver.FindElement(By.Name("availabiltyType")).SendKeys("Part Time");
        }
        
        [Then(@"my availability should be displayed on my profile")]
        public void ThenMyAvailabilityShouldBeDisplayedOnMyProfile()
        {
            try
            {
                //Start the Reports
                CommonMethods.ExtentReports();
                Thread.Sleep(1000);
                CommonMethods.test = CommonMethods.extent.StartTest("Profile add availability");

                Thread.Sleep(1000);
                string ExpectedValue = "Part Time";
                string ActualValue = Driver.driver.FindElement(By.XPath("//*[@id='account - profile - section']/div/section[2]/div/div/div/div[2]/div/div/div/div/div/div[3]/div/div[2]/div/span")).Text;
                Thread.Sleep(500);
                if (ExpectedValue == ActualValue)
                {
                    CommonMethods.test.Log(LogStatus.Pass, "Test Passed, Added avalibility Successfully");
                    SaveScreenShotClass.SaveScreenshot(Driver.driver, "AvalibilityAdded");
                }

                else
                    CommonMethods.test.Log(LogStatus.Fail, "Test Failed");

            }
            catch (Exception e)
            {
                CommonMethods.test.Log(LogStatus.Fail, "Test Failed", e.Message);
            }
        }
    }
}
