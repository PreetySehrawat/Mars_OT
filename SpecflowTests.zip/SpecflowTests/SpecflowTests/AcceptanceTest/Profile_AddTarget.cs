﻿using OpenQA.Selenium;
using RelevantCodes.ExtentReports;
using SpecflowPages;
using System;
using System.Threading;
using TechTalk.SpecFlow;
using static SpecflowPages.CommonMethods;

namespace SpecflowTests
{
    [Binding]
    public class Profile_AddTarget
    {
        [Given(@"I click on edit earn target under Profile Page")]
        public void GivenIClickOnEditEarnTargetUnderProfilePage()
        {
            // Click on Add Target
            Driver.driver.FindElement(By.CssSelector("#account-profile-section > div > section:nth-child(3) > div > div > div > div.four.wide.column > div > div > div > div > div > div.extra.content > div > div:nth-child(4) > div > span > i")).Click();
        }
        
        [When(@"I choose my earn target")]
        public void WhenIChooseMyEarnTarget()
        {
            //Choose Target
            Driver.driver.FindElement(By.Name("availabiltyTarget")).SendKeys("Between $500 and $1000 per month");
        }
        
        [Then(@"my earn target should be displayed on my profile")]
        public void ThenMyEarnTargetShouldBeDisplayedOnMyProfile()
        {
            try
            {
                //Start the Reports
                CommonMethods.ExtentReports();
                Thread.Sleep(1000);
                CommonMethods.test = CommonMethods.extent.StartTest("Profile add Target");

                Thread.Sleep(1000);
                string ExpectedValue = "Between $500 and $1000 per month";
                string ActualValue = Driver.driver.FindElement(By.XPath("//*[@id='account - profile - section']/div/section[2]/div/div/div/div[2]/div/div/div/div/div/div[3]/div/div[4]/div/span")).Text;
                Thread.Sleep(500);
                if (ExpectedValue == ActualValue)
                {
                    CommonMethods.test.Log(LogStatus.Pass, "Test Passed, Target added Successfully");
                    SaveScreenShotClass.SaveScreenshot(Driver.driver, "TargetAdded");
                }

                else
                    CommonMethods.test.Log(LogStatus.Fail, "Test Failed");

            }
            catch (Exception e)
            {
                CommonMethods.test.Log(LogStatus.Fail, "Test Failed", e.Message);
            }
        }
    }
}
