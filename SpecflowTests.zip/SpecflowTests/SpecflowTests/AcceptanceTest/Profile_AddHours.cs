﻿using OpenQA.Selenium;
using RelevantCodes.ExtentReports;
using SpecflowPages;
using System;
using System.Threading;
using TechTalk.SpecFlow;
using static SpecflowPages.CommonMethods;

namespace SpecflowTests.AcceptanceTest
{
    [Binding]
    public class Profile_AddHours
    {
        [Given(@"I click on edit hours under Profile page")]
        public void GivenIClickOnEditHoursUnderProfilePage()
        {
            // Click on Add Hours
            Driver.driver.FindElement(By.CssSelector("#account-profile-section > div > section:nth-child(3) > div > div > div > div.four.wide.column > div > div > div > div > div > div.extra.content > div > div:nth-child(3) > div > span > i")).Click();
        }
        
        [When(@"I choose my hours")]
        public void WhenIChooseMyHours()
        {
            //Choose hours
            Driver.driver.FindElement(By.Name("availabiltyHour")).SendKeys("More than 30hours a week");
        }
        
        [Then(@"my hours should be displayed on my profile")]
        public void ThenMyHoursShouldBeDisplayedOnMyProfile()
        {
            try
            {
                //Start the Reports
                CommonMethods.ExtentReports();
                Thread.Sleep(1000);
                CommonMethods.test = CommonMethods.extent.StartTest("Profile add Hours");

                Thread.Sleep(1000);
                string ExpectedValue = "More than 30hours a week";
                string ActualValue = Driver.driver.FindElement(By.XPath("//*[@id='account - profile - section']/div/section[2]/div/div/div/div[2]/div/div/div/div/div/div[3]/div/div[3]/div/span")).Text;
                Thread.Sleep(500);
                if (ExpectedValue == ActualValue)
                {
                    CommonMethods.test.Log(LogStatus.Pass, "Test Passed, Added Hours Successfully");
                    SaveScreenShotClass.SaveScreenshot(Driver.driver, "HoursAdded");
                }

                else
                    CommonMethods.test.Log(LogStatus.Fail, "Test Failed");

            }
            catch (Exception e)
            {
                CommonMethods.test.Log(LogStatus.Fail, "Test Failed", e.Message);
            }
        }
    }
}
